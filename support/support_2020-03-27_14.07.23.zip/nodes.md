Node statistics
===============

  * Total number of nodes
      - Sample size:        1
      - Average (mean):     2.0
      - Average (median):   2.0
      - Standard deviation: 0.0
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of nodes online
      - Sample size:        1
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        1
      - Average (mean):     2.0
      - Average (median):   2.0
      - Standard deviation: 0.0
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        1
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/jenkins_home`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.27
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;181
          + Maximum memory:   830.50 MB (870842368)
          + Allocated memory: 422.50 MB (443023360)
          + Free memory:      229.59 MB (240747416)
          + In-use memory:    192.91 MB (202275944)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-1062.18.1.el7.x86&#95;64
      - Process ID: 6 (0x6)
      - Process started: 2020-03-27 14:06:50.576+0000
      - Process uptime: 38 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Duser.home=/var/jenkins_home`

  * `python` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/home/jenkins`
      - Labels:         python
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.27
      - Java
          + Home:           `/java/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;241
          + Maximum memory:   830.50 MB (870842368)
          + Allocated memory: 57.50 MB (60293120)
          + Free memory:      41.23 MB (43233984)
          + In-use memory:    16.27 MB (17059136)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.241-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-1062.18.1.el7.x86&#95;64
      - Process ID: 34 (0x22)
      - Process started: 2020-03-27 14:07:17.433+0000
      - Process uptime: 11 sec
      - JVM startup parameters:
          + Boot classpath: `/java/jre/lib/resources.jar:/java/jre/lib/rt.jar:/java/jre/lib/sunrsasign.jar:/java/jre/lib/jsse.jar:/java/jre/lib/jce.jar:/java/jre/lib/charsets.jar:/java/jre/lib/jfr.jar:/java/jre/classes`
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

