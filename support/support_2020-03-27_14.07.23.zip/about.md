Jenkins
=======

Version details
---------------

  * Version: `2.150.3`
  * Mode:    WAR
  * Url:     null
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0&#95;181
      - Maximum memory:   830.50 MB (870842368)
      - Allocated memory: 422.50 MB (443023360)
      - Free memory:      229.59 MB (240747416)
      - In-use memory:    192.91 MB (202275944)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.181-b13
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-1062.18.1.el7.x86&#95;64
  * Process ID: 6 (0x6)
  * Process started: 2020-03-27 14:06:50.576+0000
  * Process uptime: 38 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Duser.home=/var/jenkins_home`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.11 'Ant Plugin'
  * antisamy-markup-formatter:2.0 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.10-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * artifactory:3.1.0 *(update available)* 'Jenkins Artifactory Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.10.1 *(update available)* 'Blue Ocean'
  * blueocean-autofavorite:1.2.2 *(update available)* 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.10.1 *(update available)* 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.10.1 *(update available)* 'Common API for Blue Ocean'
  * blueocean-config:1.10.1 *(update available)* 'Config API for Blue Ocean'
  * blueocean-core-js:1.10.1 *(update available)* 'Blue Ocean Core JS'
  * blueocean-dashboard:1.10.1 *(update available)* 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.2.0 *(update available)* 'Display URL for Blue Ocean'
  * blueocean-events:1.10.1 *(update available)* 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.10.1 *(update available)* 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.10.1 *(update available)* 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.10.1 *(update available)* 'i18n for Blue Ocean'
  * blueocean-jira:1.10.1 *(update available)* 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.10.1 *(update available)* 'JWT for Blue Ocean'
  * blueocean-personalization:1.10.1 *(update available)* 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.10.1 *(update available)* 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.10.1 *(update available)* 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.10.1 *(update available)* 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.10.1 *(update available)* 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.10.1 *(update available)* 'REST Implementation for Blue Ocean'
  * blueocean-web:1.10.1 *(update available)* 'Web for Blue Ocean'
  * bouncycastle-api:2.17 *(update available)* 'bouncycastle API Plugin'
  * branch-api:2.1.2 *(update available)* 'Branch API Plugin'
  * build-timeout:1.19.1 'Build Timeout'
  * cloudbees-bitbucket-branch-source:2.4.0 *(update available)* 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.11.1 'Folders Plugin'
  * command-launcher:1.3 *(update available)* 'Command Agent Launcher Plugin'
  * config-file-provider:3.4.1 *(update available)* 'Config File Provider Plugin'
  * configuration-as-code:1.36 'Configuration as Code Plugin'
  * credentials:2.3.5 'Credentials Plugin'
  * credentials-binding:1.21 'Credentials Binding Plugin'
  * display-url-api:2.3.2 'Display URL API'
  * docker-commons:1.13 *(update available)* 'Docker Commons Plugin'
  * docker-workflow:1.17 *(update available)* 'Docker Pipeline'
  * durable-task:1.34 'Durable Task Plugin'
  * email-ext:2.69 'Email Extension Plugin'
  * favorite:2.3.2 'Favorite'
  * git:4.2.2 'Jenkins Git plugin'
  * git-client:3.2.1 'Jenkins Git client plugin'
  * git-server:1.7 *(update available)* 'Jenkins GIT server Plugin'
  * gitea:1.0.8 *(update available)* 'Gitea Plugin'
  * github:1.29.3 *(update available)* 'GitHub plugin'
  * github-api:1.106 'GitHub API Plugin'
  * github-branch-source:2.6.0 'GitHub Branch Source Plugin'
  * gitlab-plugin:1.5.11 *(update available)* 'GitLab Plugin'
  * gradle:1.36 'Gradle Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.6-1.0 *(update available)* 'Handy Uri Templates 2.x API Plugin'
  * htmlpublisher:1.17 *(update available)* 'HTML Publisher plugin'
  * ivy:1.28 *(update available)* 'Ivy Plugin'
  * jackson2-api:2.10.3 'Jackson 2 API Plugin'
  * javadoc:1.4 *(update available)* 'Javadoc Plugin'
  * jdk-tool:1.4 'Oracle Java SE Development Kit Installer Plugin'
  * jenkins-design-language:1.10.1 *(update available)* 'Jenkins Design Language'
  * jira:3.0.5 *(update available)* 'Jenkins JIRA plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.55.1 'Jenkins JSch dependency plugin'
  * junit:1.26.1 *(update available)* 'JUnit Plugin'
  * jx-resources:1.0.35 *(update available)* 'JX Resources Plugin'
  * kubernetes:1.14.3 *(update available)* 'Kubernetes plugin'
  * kubernetes-credentials:0.4.0 *(update available)* 'Kubernetes Credentials Plugin'
  * kubernetes-credentials-provider:0.11 *(update available)* 'Kubernetes Credentials Provider'
  * ldap:1.21 'LDAP Plugin'
  * localization-zh-cn:0.0.11 *(update available)* 'Localization: Chinese (Simplified)'
  * lockable-resources:2.3 *(update available)* 'Lockable Resources plugin'
  * mailer:1.30 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.5 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.14 'Matrix Project Plugin'
  * maven-plugin:3.2 *(update available)* 'Maven Integration plugin'
  * mercurial:2.4 *(update available)* 'Jenkins Mercurial plugin'
  * metrics:4.0.2.2 *(update available)* 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.6 'PAM Authentication plugin'
  * pipeline-build-step:2.7 *(update available)* 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.9 *(update available)* 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.9 *(update available)* 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.3.4.1 *(update available)* 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.3.4.1 *(update available)* 'Pipeline: Declarative'
  * pipeline-model-extensions:1.3.4.1 *(update available)* 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.13 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.3.4.1 *(update available)* 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.13 'Pipeline: Stage View Plugin'
  * plain-credentials:1.5 *(update available)* 'Plain Credentials Plugin'
  * pubsub-light:1.12 *(update available)* 'Jenkins Pub-Sub "light" Bus'
  * resource-disposer:0.12 *(update available)* 'Resource Disposer Plugin'
  * scm-api:2.6.3 'SCM API Plugin'
  * script-security:1.71 'Script Security Plugin'
  * sse-gateway:1.17 *(update available)* 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.17.4 'SSH Credentials Plugin'
  * ssh-slaves:1.30.4 'Jenkins SSH Slaves plugin'
  * structs:1.20 'Structs Plugin'
  * subversion:2.13.1 'Jenkins Subversion Plug-in'
  * support-core:2.54 *(update available)* 'Support Core Plugin'
  * timestamper:1.11.2 'Timestamper'
  * token-macro:2.12 'Token Macro Plugin'
  * variant:1.1 *(update available)* 'Variant Plugin'
  * workflow-aggregator:2.6 'Pipeline'
  * workflow-api:2.40 'Pipeline: API'
  * workflow-basic-steps:2.19 'Pipeline: Basic Steps'
  * workflow-cps:2.80 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.12 *(update available)* 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.31 'Pipeline: Nodes and Processes'
  * workflow-job:2.37 'Pipeline: Job'
  * workflow-multibranch:2.20 *(update available)* 'Pipeline: Multibranch'
  * workflow-scm-step:2.10 'Pipeline: SCM Step'
  * workflow-step-api:2.22 'Pipeline: Step API'
  * workflow-support:3.4 'Pipeline: Supporting APIs'
  * ws-cleanup:0.38 'Jenkins Workspace Cleanup Plugin'
