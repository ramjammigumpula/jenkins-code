Jenkins
=======

Version details
---------------

  * Version: `2.150.3`
  * Mode:    WAR
  * Url:     null
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0&#95;181
      - Maximum memory:   239.75 MB (251396096)
      - Allocated memory: 83.91 MB (87990272)
      - Free memory:      17.96 MB (18830208)
      - In-use memory:    65.96 MB (69160064)
      - GC strategy:      SerialGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.181-b13
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-957.12.2.el7.x86&#95;64
  * Process ID: 6 (0x6)
  * Process started: 2020-03-24 06:49:02.210+0000
  * Process uptime: 1 min 50 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Duser.home=/var/jenkins_home`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Loaded all jobs
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.9 'Ant Plugin'
  * apache-httpcomponents-client-4-api:4.5.5-3.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * artifactory:3.1.0 'Jenkins Artifactory Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.10.1 'Blue Ocean'
  * blueocean-autofavorite:1.2.2 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.10.1 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.10.1 'Common API for Blue Ocean'
  * blueocean-config:1.10.1 'Config API for Blue Ocean'
  * blueocean-core-js:1.10.1 'Blue Ocean Core JS'
  * blueocean-dashboard:1.10.1 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.2.0 'Display URL for Blue Ocean'
  * blueocean-events:1.10.1 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.10.1 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.10.1 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.10.1 'i18n for Blue Ocean'
  * blueocean-jira:1.10.1 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.10.1 'JWT for Blue Ocean'
  * blueocean-personalization:1.10.1 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.10.1 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.10.1 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.10.1 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.10.1 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.10.1 'REST Implementation for Blue Ocean'
  * blueocean-web:1.10.1 'Web for Blue Ocean'
  * bouncycastle-api:2.17 'bouncycastle API Plugin'
  * branch-api:2.1.2 'Branch API Plugin'
  * cloudbees-bitbucket-branch-source:2.4.0 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.7 'Folders Plugin'
  * command-launcher:1.3 'Command Agent Launcher Plugin'
  * config-file-provider:3.4.1 'Config File Provider Plugin'
  * configuration-as-code:1.4 'Configuration as Code Plugin'
  * credentials:2.1.18 'Credentials Plugin'
  * credentials-binding:1.17 'Credentials Binding Plugin'
  * display-url-api:2.3.0 'Display URL API'
  * docker-commons:1.13 'Docker Commons Plugin'
  * docker-workflow:1.17 'Docker Pipeline'
  * durable-task:1.28 'Durable Task Plugin'
  * favorite:2.3.2 'Favorite'
  * git:3.9.1 'Jenkins Git plugin'
  * git-client:2.7.6 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * gitea:1.0.8 'Gitea Plugin'
  * github:1.29.3 'GitHub plugin'
  * github-api:1.95 'GitHub API Plugin'
  * github-branch-source:2.4.2 'GitHub Branch Source Plugin'
  * gitlab-plugin:1.5.11 'GitLab Plugin'
  * gradle:1.30 'Gradle Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.6-1.0 'Handy Uri Templates 2.x API Plugin'
  * htmlpublisher:1.17 'HTML Publisher plugin'
  * ivy:1.28 'Ivy Plugin'
  * jackson2-api:2.9.8 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jenkins-design-language:1.10.1 'Jenkins Design Language'
  * jira:3.0.5 'Jenkins JIRA plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.55 'Jenkins JSch dependency plugin'
  * junit:1.26.1 'JUnit Plugin'
  * jx-resources:1.0.35 'JX Resources Plugin'
  * kubernetes:1.14.3 'Kubernetes plugin'
  * kubernetes-credentials:0.4.0 'Kubernetes Credentials Plugin'
  * kubernetes-credentials-provider:0.11 'Kubernetes Credentials Provider'
  * localization-zh-cn:0.0.11 'Localization: Chinese (Simplified)'
  * lockable-resources:2.3 'Lockable Resources plugin'
  * mailer:1.23 'Jenkins Mailer Plugin'
  * matrix-project:1.13 'Matrix Project Plugin'
  * maven-plugin:3.2 'Maven Integration plugin'
  * mercurial:2.4 'Jenkins Mercurial plugin'
  * metrics:4.0.2.2 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pipeline-build-step:2.7 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.9 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.9 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.3.4.1 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.3.4.1 'Pipeline: Declarative'
  * pipeline-model-extensions:1.3.4.1 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.10 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.3.4.1 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.10 'Pipeline: Stage View Plugin'
  * plain-credentials:1.5 'Plain Credentials Plugin'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * resource-disposer:0.12 'Resource Disposer Plugin'
  * scm-api:2.3.0 'SCM API Plugin'
  * script-security:1.50 'Script Security Plugin'
  * sse-gateway:1.17 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.14 'SSH Credentials Plugin'
  * structs:1.17 'Structs Plugin'
  * support-core:2.54 'Support Core Plugin'
  * token-macro:2.5 'Token Macro Plugin'
  * variant:1.1 'Variant Plugin'
  * workflow-aggregator:2.6 'Pipeline'
  * workflow-api:2.33 'Pipeline: API'
  * workflow-basic-steps:2.14 'Pipeline: Basic Steps'
  * workflow-cps:2.62 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.12 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.28 'Pipeline: Nodes and Processes'
  * workflow-job:2.31 'Pipeline: Job'
  * workflow-multibranch:2.20 'Pipeline: Multibranch'
  * workflow-scm-step:2.7 'Pipeline: SCM Step'
  * workflow-step-api:2.18 'Pipeline: Step API'
  * workflow-support:3.0 'Pipeline: Supporting APIs'
  * ws-cleanup:0.37 'Jenkins Workspace Cleanup Plugin'
