Monitors
========

`jenkins.diagnostics.CompletedInitializationMonitor`
--------------
(active and enabled)

`jenkins.diagnostics.RootUrlNotSetMonitor`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)
