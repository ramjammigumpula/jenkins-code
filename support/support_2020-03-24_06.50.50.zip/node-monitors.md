Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: null
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: null
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: null
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: null
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: null
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: null
