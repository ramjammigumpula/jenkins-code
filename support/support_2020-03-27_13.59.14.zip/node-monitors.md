Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * python: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * python: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 7.641GB left on /var/jenkins_home.
   * python: Disk space is too low. Only 8.432GB left on /home/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:167/3729MB  Swap:2047/2047MB
   * python: Memory:165/3729MB  Swap:2047/2047MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 9.622GB left on /tmp.
   * python: Disk space is too low. Only 8.432GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * python: 92ms
