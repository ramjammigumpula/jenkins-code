=== Sites ===
 - Url: https://updates.jenkins.io/update-center.json
 - Connection Url: http://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
======
Last updated: 7 min 3 sec
Proxy: 'async-http-client' not installed, so no proxy info available.
