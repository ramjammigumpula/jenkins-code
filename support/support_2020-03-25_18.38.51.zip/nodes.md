Node statistics
===============

  * Total number of nodes
      - Sample size:        241
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        241
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        241
      - Average (mean):     1.9999999999999996
      - Average (median):   2.0
      - Standard deviation: 4.4408920985006257E-16
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        241
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/jenkins_home`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.27
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;181
          + Maximum memory:   830.50 MB (870842368)
          + Allocated memory: 426.50 MB (447217664)
          + Free memory:      102.66 MB (107646264)
          + In-use memory:    323.84 MB (339571400)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-1062.18.1.el7.x86&#95;64
      - Process ID: 6 (0x6)
      - Process started: 2020-03-25 17:38:13.175+0000
      - Process uptime: 1 hr 0 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Duser.home=/var/jenkins_home`

