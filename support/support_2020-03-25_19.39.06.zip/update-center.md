=== Sites ===
 - Url: https://updates.jenkins.io/update-center.json
 - Connection Url: http://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
======
Last updated: 2 hr 1 min
Proxy: 'async-http-client' not installed, so no proxy info available.
