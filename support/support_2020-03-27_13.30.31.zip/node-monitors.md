Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 7.823GB left on /var/jenkins_home.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:529/3729MB  Swap:2047/2047MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 9.622GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
