Support Bundle Manifest
=======================

Generated on 2020-03-27 14:25:48.992+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2020-03-24_06.57.48.log`

      - `nodes/master/logs/all_2020-03-24_07.14.38.log`

      - `nodes/master/logs/all_2020-03-25_17.38.19.log`

      - `nodes/master/logs/all_2020-03-25_20.27.57.log`

      - `nodes/master/logs/all_2020-03-27_13.30.09.log`

      - `nodes/master/logs/all_2020-03-27_13.58.57.log`

      - `nodes/master/logs/all_2020-03-27_14.06.59.log`

      - `nodes/master/logs/all_2020-03-27_14.25.21.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Download metadata.log`

      - `other-logs/Download metadata.log.1`

      - `other-logs/Download metadata.log.2`

      - `other-logs/Download metadata.log.3`

      - `other-logs/Download metadata.log.4`

      - `other-logs/Download metadata.log.5`

      - `other-logs/Purge expired KubernetesClients.log`

      - `other-logs/Purge expired KubernetesClients.log.1`

      - `other-logs/Purge expired KubernetesClients.log.2`

      - `other-logs/Purge expired KubernetesClients.log.3`

      - `other-logs/Purge expired KubernetesClients.log.4`

      - `other-logs/Purge expired KubernetesClients.log.5`

      - `other-logs/copy_reference_file.log`

      - `other-logs/health-checker.log`

  * Agent Log Recorders

      - `nodes/slave/python/jenkins.log`

      - `nodes/slave/python/logs/all_2020-03-27_13.18.10.log`

      - `nodes/slave/python/logs/all_2020-03-27_14.25.44.log`

      - `nodes/slave/python/logs/all_memory_buffer.log`

  * Garbage Collection Logs

  * Agents config files (Encrypted secrets are redacted)

      - `nodes/slave/python/config.xml`

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/com.cloudbees.hudson.plugins.folder.config.AbstractFolderConfiguration.xml`

      - `jenkins-root-configuration-files/com.dabsquared.gitlabjenkins.GitLabPushTrigger.xml`

      - `jenkins-root-configuration-files/com.dabsquared.gitlabjenkins.connection.GitLabConnectionConfig.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/jenkins.CLI.xml`

      - `jenkins-root-configuration-files/jenkins.telemetry.Correlator.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.jx.resources.GlobalPluginConfiguration.xml`

  * About browser

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/python/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/python/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/python/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/python/file-descriptors.txt`

  * Master Heap Histogram

      - `nodes/master/heap-histogram.txt`

  * Agent JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/python/proc/meminfo.txt`

      - `nodes/slave/python/proc/self/cmdline`

      - `nodes/slave/python/proc/self/environ`

      - `nodes/slave/python/proc/self/limits.txt`

      - `nodes/slave/python/proc/self/mountstats.txt`

      - `nodes/slave/python/proc/self/status.txt`

  * Master JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/python/proc/meminfo.txt`

      - `nodes/slave/python/proc/self/cmdline`

      - `nodes/slave/python/proc/self/environ`

      - `nodes/slave/python/proc/self/limits.txt`

      - `nodes/slave/python/proc/self/mountstats.txt`

      - `nodes/slave/python/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/python/gnuplot`

      - `load-stats/label/python/hour.csv`

      - `load-stats/label/python/min.csv`

      - `load-stats/label/python/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/python/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Root CAs

      - `nodes/master/RootCA.txt`

      - `nodes/slave/python/RootCA.txt`

  * Agent Command Statistics

      - `nodes/slave/python/command-stats.md`

  * Agent system configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/python/dmesg.txt`

      - `nodes/slave/python/dmi.txt`

      - `nodes/slave/python/proc/cpuinfo.txt`

      - `nodes/slave/python/proc/mounts.txt`

      - `nodes/slave/python/proc/net/rpc/nfs.txt`

      - `nodes/slave/python/proc/net/rpc/nfsd.txt`

      - `nodes/slave/python/proc/swaps.txt`

      - `nodes/slave/python/proc/system-uptime.txt`

      - `nodes/slave/python/sysctl.txt`

      - `nodes/slave/python/userid.txt`

  * Master system configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/python/dmesg.txt`

      - `nodes/slave/python/dmi.txt`

      - `nodes/slave/python/proc/cpuinfo.txt`

      - `nodes/slave/python/proc/mounts.txt`

      - `nodes/slave/python/proc/net/rpc/nfs.txt`

      - `nodes/slave/python/proc/net/rpc/nfsd.txt`

      - `nodes/slave/python/proc/swaps.txt`

      - `nodes/slave/python/proc/system-uptime.txt`

      - `nodes/slave/python/sysctl.txt`

      - `nodes/slave/python/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/python/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

      - `slow-requests/20200324-072947.011.txt`

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/python/thread-dump.txt`

